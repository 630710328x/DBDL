import 'package:flutter/material.dart';
import '../../models/project.dart';
import 'package:untitled2/pages/project/project_list_page.dart';

class ProjectDetailsPage extends StatelessWidget {
  final Project project;
  const ProjectDetailsPage({Key? key, required this.project}) : super(key: key);

  @override
  Widget build(BuildContext context)
  {
    return Scaffold(
      appBar: AppBar(
          title: Text(
            project.title,
            overflow: TextOverflow.ellipsis,

          )),
      body: Container(
          child: Column(
            children: [
              Text('อิ่่มท้องน้องพิเศษ' ,style: TextStyle(fontSize: 20.0),)
            ],
          ),
      ),
    );
  }
}